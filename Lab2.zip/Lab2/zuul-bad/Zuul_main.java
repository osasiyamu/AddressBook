public class Zuul_main {
    public static void main(String[] args) {
        Game game = new Game();
        game.play();
    }
}
